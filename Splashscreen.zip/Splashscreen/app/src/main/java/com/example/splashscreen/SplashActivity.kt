package com.example.splashscreen

import android.animation.ObjectAnimator
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.ImageView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_splash)
        
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.splash_root)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        //This takes the truck logo button
        val truckLogo = findViewById<ImageView>(R.id.truck_logo)

        // the code below is an animation and will move the truck from left to right
        val screen_Width = resources.displayMetrics.widthPixels.toFloat()
        val animation = ObjectAnimator.ofFloat(truckLogo, "translationX", 0f, screen_Width + 300f)
        animation.duration = 2000 // 2 seconds
        animation.start()

        // This will  transition to the login screen after 2.5 seconds
        Handler(Looper.getMainLooper()).postDelayed({
           // startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }, 2500) // This will delay slightly longer than animation
    }
}